using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Finance.Pages
{
    public class BankAccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
