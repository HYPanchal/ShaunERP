using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Finance.Pages
{
    public class VendorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
