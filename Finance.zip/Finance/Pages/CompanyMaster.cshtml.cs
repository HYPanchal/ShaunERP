using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Finance.Pages
{
    public class CompanyMasterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
