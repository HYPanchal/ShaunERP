using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Finance.Pages
{
    public class TaxRateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
