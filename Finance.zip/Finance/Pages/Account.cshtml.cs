using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Finance.Pages
{
    public class AccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
